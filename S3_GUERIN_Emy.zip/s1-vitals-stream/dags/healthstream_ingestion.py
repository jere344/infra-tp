import json
import logging
from datetime import timedelta
from pathlib import Path

import pendulum
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import PythonOperator
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator

logger = logging.getLogger(__name__)

CONN_PG = "healthstream_pg"
DOSSIER_RAPPORTS = Path("/opt/airflow/data/rapports")
DOSSIER_ALERTES = Path("/opt/airflow/data/alertes")


# --------------------------------------------------------------------------- #
# Outil partagé : lag d'un consumer group, SANS rejoindre le groupe.
# --------------------------------------------------------------------------- #
def _lag_du_groupe(bootstrap, topic, groupe):
    # Import lourd dans la fonction : le scheduler rejoue le module toutes les 30 s.
    from confluent_kafka import Consumer, TopicPartition

    c = Consumer({
        "bootstrap.servers": bootstrap,
        "group.id": groupe,
        "enable.auto.commit": False,
    })
    try:
        meta = c.list_topics(topic, timeout=10)
        parts = [TopicPartition(topic, p) for p in sorted(meta.topics[topic].partitions)]
        lag_total = 0
        detail = {}
        # committed() = requête OffsetFetch : on ne s'abonne pas, donc pas de rééquilibrage.
        for tp in c.committed(parts, timeout=10):
            bas, haut = c.get_watermark_offsets(tp, timeout=10, cached=False)
            # offset négatif = aucun commit : on part du début de la partition.
            commite = tp.offset if tp.offset >= 0 else bas
            lag = haut - commite
            detail[tp.partition] = lag
            lag_total += lag
        return lag_total, detail
    finally:
        c.close()


# --------------------------------------------------------------------------- #
# Tâches
# --------------------------------------------------------------------------- #
def verifier_broker(**context):
    from airflow.models import Variable
    from confluent_kafka.admin import AdminClient

    topic = Variable.get("vitals_topic")
    admin = AdminClient({"bootstrap.servers": Variable.get("kafka_bootstrap")})
    md = admin.list_topics(timeout=10)
    if topic not in md.topics:
        raise RuntimeError(f"topic {topic!r} absent du broker")
    nb = len(md.topics[topic].partitions)
    print(f"broker OK, topic {topic} : {nb} partitions")
    return nb


def relever_offsets_avant(**context):
    from airflow.models import Variable

    total, detail = _lag_du_groupe(
        Variable.get("kafka_bootstrap"),
        Variable.get("vitals_topic"),
        Variable.get("vitals_group"),
    )
    print(f"lag_before = {total} (détail {detail})")
    context["task_instance"].xcom_push(key="lag_avant", value=total)


def controler_lag(**context):
    import time

    from airflow.models import Variable

    seuil = int(Variable.get("lag_max"))
    attente_max_s = 120
    pas_s = 10
    bootstrap = Variable.get("kafka_bootstrap")
    topic = Variable.get("vitals_topic")
    groupe = Variable.get("vitals_group")

    debut = time.monotonic()
    while True:
        total, detail = _lag_du_groupe(bootstrap, topic, groupe)
        print(f"lag mesuré = {total} (seuil {seuil}) détail {detail}")
        if total <= seuil:
            break
        if time.monotonic() - debut >= attente_max_s:
            raise RuntimeError(
                f"lag {total} toujours > seuil {seuil} après {attente_max_s} s ; "
                f"détail par partition : {detail}"
            )
        time.sleep(pas_s)

    ti = context["task_instance"]
    ti.xcom_push(key="lag_apres", value=total)
    ti.xcom_push(key="lag_detail", value=detail)


def verifier_integrite(**context):
    from airflow.providers.postgres.hooks.postgres import PostgresHook

    # L'intervalle du RUN, pas l'heure courante : c'est ce qui rend le run rejouable.
    debut = context["data_interval_start"]  # et NON pendulum.now()
    fin = context["data_interval_end"]
    print(f"fenêtre du run : [{debut}, {fin})")

    requete = """
        SELECT count(*)                                              AS lignes,
               count(DISTINCT patient_id)                            AS patients,
               count(*) FILTER (WHERE value IS NULL)                 AS nulles,
               count(*) FILTER (WHERE vital_type NOT IN ('HR','SPO2','ABP_SYS')) AS types_inconnus,
               count(*) FILTER (WHERE vital_type = 'SPO2' AND value > 100)       AS spo2_impossibles
        FROM vitals_raw
        WHERE ingested_at >= %s AND ingested_at < %s
    """
    hook = PostgresHook(postgres_conn_id=CONN_PG)
    lignes, patients, nulles, types_inconnus, spo2 = hook.get_first(
        requete, parameters=(debut, fin)
    )
    integrite = {
        "lignes": lignes,
        "patients": patients,
        "nulles": nulles,
        "types_inconnus": types_inconnus,
        "spo2_impossibles": spo2,
    }
    print("intégrité :", integrite)
    context["task_instance"].xcom_push(key="integrite", value=integrite)

    if lignes == 0:
        raise ValueError(f"aucune ligne dans vitals_raw sur la fenêtre [{debut}, {fin})")
    if nulles or types_inconnus or spo2:
        raise ValueError(f"anomalies détectées sur la fenêtre [{debut}, {fin}) : {integrite}")


def ecrire_rapport(**context):
    from airflow.providers.postgres.hooks.postgres import PostgresHook

    ti = context["task_instance"]
    lag_avant = ti.xcom_pull(task_ids="relever_offsets_avant", key="lag_avant")
    lag_apres = ti.xcom_pull(task_ids="controler_lag", key="lag_apres")
    integ = ti.xcom_pull(task_ids="verifier_integrite", key="integrite")
    debut = context["data_interval_start"]
    fin = context["data_interval_end"]

    hook = PostgresHook(postgres_conn_id=CONN_PG)
    # En base : la clé primaire (dag_id, window_start) absorbe le rejeu.
    hook.run(
        """
        INSERT INTO ingestion_report
            (dag_id, window_start, window_end, rows_ingested, patients,
             null_values, unknown_types, lag_before, lag_after)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (dag_id, window_start) DO UPDATE SET
            window_end    = EXCLUDED.window_end,
            rows_ingested = EXCLUDED.rows_ingested,
            patients      = EXCLUDED.patients,
            null_values   = EXCLUDED.null_values,
            unknown_types = EXCLUDED.unknown_types,
            lag_before    = EXCLUDED.lag_before,
            lag_after     = EXCLUDED.lag_after,
            run_count     = ingestion_report.run_count + 1,
            updated_at    = now();
        """,
        parameters=(
            context["dag"].dag_id, debut, fin, integ["lignes"], integ["patients"],
            integ["nulles"], integ["types_inconnus"], lag_avant, lag_apres,
        ),
    )

    # Sur disque : nom dérivé du DÉBUT DE FENÊTRE, jamais de l'heure courante.
    # Un rejeu ÉCRASE le fichier, il n'en crée pas un second.
    DOSSIER_RAPPORTS.mkdir(parents=True, exist_ok=True)
    chemin = DOSSIER_RAPPORTS / f"ingestion_{debut.format('YYYYMMDD_HH')}.json"
    chemin.write_text(json.dumps({
        "dag_id": context["dag"].dag_id,
        "window_start": str(debut),
        "window_end": str(fin),
        "rows_ingested": integ["lignes"],
        "patients": integ["patients"],
        "null_values": integ["nulles"],
        "unknown_types": integ["types_inconnus"],
        "lag_before": lag_avant,
        "lag_after": lag_apres,
    }, indent=2))
    print(f"rapport écrit : {chemin}")


# --------------------------------------------------------------------------- #
# DAG
# --------------------------------------------------------------------------- #
def alerter_echec(context):
    """Alerte d'échec définitif : quoi, quand, pourquoi, où regarder."""
    ti = context["task_instance"]
    alerte = {
        "gravite": "CRITIQUE",
        "dag_id": context["dag"].dag_id,
        "task_id": ti.task_id,
        "run_id": context["run_id"],
        "fenetre": str(context["data_interval_start"]),
        "tentative": ti.try_number,
        "erreur": str(context.get("exception", "inconnue")),
        "journal": f"/opt/airflow/logs/dag_id={context['dag'].dag_id}"
                   f"/run_id={context['run_id']}/task_id={ti.task_id}/",
        "horodatage": pendulum.now("Europe/Paris").isoformat(),
    }
    DOSSIER_ALERTES.mkdir(parents=True, exist_ok=True)
    chemin = DOSSIER_ALERTES / f"alerte_{context['run_id']}_{ti.task_id}.json"
    chemin.write_text(json.dumps(alerte, indent=2, ensure_ascii=False))
    logger.error("ALERTE %s", json.dumps(alerte, ensure_ascii=False))


def tracer_tentative(context):
    """Appelée avant chaque nouvelle tentative : rend le backoff visible."""
    ti = context["task_instance"]
    logger.warning(
        "nouvelle tentative de %s (essai %s) après : %s",
        ti.task_id, ti.try_number, context.get("exception"),
    )


default_args = {
    "owner": "icu-ops",
    "retries": 2,
    "retry_delay": timedelta(seconds=30),
    "retry_exponential_backoff": True,
    "max_retry_delay": timedelta(minutes=5),
    "execution_timeout": timedelta(minutes=3),
    "on_failure_callback": alerter_echec,
    "on_retry_callback": tracer_tentative,
}

with DAG(
    dag_id="healthstream_ingestion",
    default_args=default_args,
    schedule="@hourly",
    start_date=pendulum.datetime(2026, 9, 1, tz="Europe/Paris"),
    catchup=False,
    max_active_runs=1,
    tags=["s3", "healthstream"],
) as dag:
    creer_table_rapport = SQLExecuteQueryOperator(
        task_id="creer_table_rapport",
        conn_id=CONN_PG,
        sql="""
            CREATE TABLE IF NOT EXISTS ingestion_report (
                dag_id        text        NOT NULL,
                window_start  timestamptz NOT NULL,
                window_end    timestamptz NOT NULL,
                rows_ingested integer     NOT NULL,
                patients      integer     NOT NULL,
                null_values   integer     NOT NULL,
                unknown_types integer     NOT NULL,
                lag_before    bigint,
                lag_after     bigint,
                run_count     integer     NOT NULL DEFAULT 1,
                updated_at    timestamptz NOT NULL DEFAULT now(),
                PRIMARY KEY (dag_id, window_start)
            );
        """,
    )
    t_broker = PythonOperator(task_id="verifier_broker", python_callable=verifier_broker)
    t_avant = PythonOperator(task_id="relever_offsets_avant", python_callable=relever_offsets_avant)
    produire = BashOperator(
        task_id="produire_fenetre",
        bash_command=(
            "timeout --preserve-status --signal=TERM {{ var.value.fenetre_duree_s }} "
            "python /opt/airflow/producer/producer.py"
        ),
        append_env=True,
        env={
            "KAFKA_BOOTSTRAP": "{{ var.value.kafka_bootstrap }}",
            "VITALS_TOPIC": "{{ var.value.vitals_topic }}",
            "NB_PATIENTS": "12",
            "INTERVAL_S": "1.0",
        },
    )
    t_lag = PythonOperator(task_id="controler_lag", python_callable=controler_lag)
    t_integrite = PythonOperator(task_id="verifier_integrite", python_callable=verifier_integrite)
    t_rapport = PythonOperator(task_id="ecrire_rapport", python_callable=ecrire_rapport)
    fin_pipeline = EmptyOperator(task_id="fin_pipeline")

    (
        creer_table_rapport
        >> t_broker
        >> t_avant
        >> produire
        >> t_lag
        >> t_integrite
        >> t_rapport
        >> fin_pipeline
    )
