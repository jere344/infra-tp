--
-- PostgreSQL database dump
--

\restrict On0PYk0EbvapL08lEJOk79ZEQ7fmap6dFsOR0XhG6btBi8BpmHFaNFV8M22FbqE

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: vitals_raw; Type: TABLE; Schema: public; Owner: hs_user
--

CREATE TABLE public.vitals_raw (
    kafka_partition integer NOT NULL,
    kafka_offset bigint NOT NULL,
    patient_id character varying(16) NOT NULL,
    event_time timestamp with time zone NOT NULL,
    vital_type character varying(16) NOT NULL,
    value numeric(8,2) NOT NULL,
    unit character varying(8) NOT NULL,
    ingested_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_vital_type CHECK (((vital_type)::text = ANY ((ARRAY['HR'::character varying, 'SPO2'::character varying, 'ABP_SYS'::character varying])::text[])))
);


ALTER TABLE public.vitals_raw OWNER TO hs_user;

--
-- Name: v_vitals_controle; Type: VIEW; Schema: public; Owner: hs_user
--

CREATE VIEW public.v_vitals_controle AS
 SELECT count(*) AS lignes_totales,
    count(DISTINCT ROW(kafka_partition, kafka_offset)) AS messages_distincts,
    count(DISTINCT patient_id) AS patients_distincts,
    min(event_time) AS premier_releve,
    max(event_time) AS dernier_releve
   FROM public.vitals_raw;


ALTER VIEW public.v_vitals_controle OWNER TO hs_user;

--
-- Name: vitals_raw pk_vitals_raw; Type: CONSTRAINT; Schema: public; Owner: hs_user
--

ALTER TABLE ONLY public.vitals_raw
    ADD CONSTRAINT pk_vitals_raw PRIMARY KEY (kafka_partition, kafka_offset);


--
-- Name: idx_vitals_patient_time; Type: INDEX; Schema: public; Owner: hs_user
--

CREATE INDEX idx_vitals_patient_time ON public.vitals_raw USING btree (patient_id, event_time DESC);


--
-- PostgreSQL database dump complete
--

\unrestrict On0PYk0EbvapL08lEJOk79ZEQ7fmap6dFsOR0XhG6btBi8BpmHFaNFV8M22FbqE

