# Mesures — séance 3

## Vérification des prérequis

| Grandeur | Valeur relevée sur votre poste |
| --- | --- |
| Version de Docker Engine | `29.9.3` |
| Mémoire allouée au moteur Docker (Go) | `14,39` (Gio) |
| Mémoire consommée par la pile de la séance 2 seule (`docker stats --no-stream`) | `≈ 513 MiB` (kafka 409,5 + postgres 80,3 + consumer 13,8 + producer 9,6) |

## Contrat d'entrée

| Contrôle | Valeur relevée |
| --- | --- |
| Nombre de partitions de `mimic-vitals` | `6` |
| Topic recréé au début de cette séance (oui / non) | `oui` |
| Nombre de lignes déjà présentes dans `vitals_raw` | `0` |

## Partie 1 — Airflow dans le Compose existant

### Mesure 1 — coût mémoire d'Airflow

| Grandeur | Valeur relevée |
| --- | --- |
| Mémoire totale de la pile **séance 2 seule** | `≈ 513 MiB` |
| Mémoire totale de la pile **avec Airflow** | `≈ 1369 MiB` (web 761,7 + kafka 277,8 + scheduler 236,4 + postgres 63,4 + consumer 15,1 + producer 14,5) |
| Conteneur le plus gourmand, et sa consommation | `vitals-airflow-web`, `761,7 MiB` |

### Mesure 2 — coût en temps du démarrage

| Grandeur | Valeur relevée |
| --- | --- |
| Durée de `airflow-init` (migration + création du compte) | `26` s (11:04:48,34 → 11:05:14,06) |
| Délai entre `up -d` et webserver `healthy` | `114` s (`up -d` à 11:04:40 UTC, premier `healthy` à 11:06:33,9 UTC) |

### Question 1.1

En dev, utiliser la même base de données PostgreSQL facilite le développement et permet d'économiser de la mémoire, mais en production il vaudrait mieux utiliser une base de données séparée pour découpler des données qui sont indépendantes, ce qui améliore la stabilité. En production les données sont indépendantes : si l'une crashe, l'autre ne doit pas suivre. De plus, en production on peut s'attendre à avoir plusieurs applicatifs, chacun avec sa propre base de données et potentiellement des technologies différentes, qui utilisent le même Airflow.

### 1.5 — Coupes appliquées

Aucune : le moteur Docker dispose de 14,39 Gio, la pile complète en consomme ≈ 1,34 Gio.

## Partie 2 — Premier DAG

### Mesure 3 — délai de détection

| Grandeur | Valeur relevée |
| --- | --- |
| Délai entre l'enregistrement de `premier_dag_s3.py` et son apparition | `7` s (fichier écrit à 11:24:43 UTC, présent en base à 11:24:50 UTC) |
| Valeur de `AIRFLOW__SCHEDULER__DAG_DIR_LIST_INTERVAL` dans votre Compose | `60` s |

### Question 2.1

`data_interval_start` vaut la date d'hier : le 18 novembre à 00:00 heure de Paris (affiché 17 novembre 23:00 dans les journaux, timezone). Comme le `schedule` est `@daily`, un run traite une journée entière et ne part que quand cette fenêtre est complète : à midi le 19, la dernière fenêtre complète est celle du 18, de 00:00 au 19 à 00:00. Un run manuel reçoit cette même fenêtre déduite. L'heure réelle du clic est noté dans logical_date.


## Partie 3 — Orchestrer la chaîne réelle

### Mesure 4 — la fenêtre d'ingestion

Run `scheduled__2026-11-19T12:00:00+00:00` (fenêtre 2026-11-19 12:00 → 13:00 UTC), `INTERVAL_S` = `1.0`, `FENETRE_DUREE_S` = `60`.

| Grandeur | Valeur relevée |
| --- | --- |
| `lag_before` (journaux de `relever_offsets_avant`) | `0` (détail `{0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0}`) |
| Lag maximal observé pendant `controler_lag` | `0` (une seule mesure, sous le seuil de 200) |
| `lag_after` final | `0` |
| `rows_ingested` dans le rapport | `720` |
| Écart entre `rows_ingested` et `12 × FENETRE_DUREE_S` | `0` (720 − 12 × 60) |


### Question 3.1

Si controler_lag ouvre un Consumer qui suscribe au flux, kafka va rééquilibrer les envois entre controler_lag et le consumer. Controler_lag ne fait que mesurer, donc ses partitions ne sont pas réellement lu, et leur lag monte. Globalement, si controler_lag suscribe au flux, il perturbera son opération au lieu de simplement l'observer.

### Question 3.2

En cas de décallage entre le temps de mesure et le temps d'ingestion les deux filtres ne donneraient plus la même chose. Cela peut avoir lieu lors d'un lag important, lors d'un plantage par exemple. Si le consumer plant à 10h30 et redémare à 11h15, une mesure prise à 10h45 aura event_time=10h45, comptée dans la fenêtre 10h, et ingested_at=11h15, comptée dans la fenêtre 11h. Un rapport d'injection note quand la donnée à été ingérée, il faut donc regarder injected_at.

## Partie 4 — Robustesse

### 4.1 — Valeurs retenues dans `default_args`

`retries` = `2`, `retry_delay` = `timedelta(seconds=30)`, `execution_timeout` = `timedelta(minutes=3)`.

### Mesure 5 — comportement à l'échec

Kafka arrêté, run `manual__2026-11-19T14:02:50+00:00`. Délais mesurés entre la fin d'une tentative et le début de la suivante (journaux `attempt=N.log`).

| Observation | Valeur relevée |
| --- | --- |
| Nombre total d'exécutions de `verifier_broker` avant abandon | `3` |
| Délai entre la tentative 1 et la tentative 2 | `53` s (fin 14:03:03,1 → début 14:03:56,5 UTC) |
| Délai entre la tentative 2 et la tentative 3 | `116` s (fin 14:04:07,0 → début 14:06:02,6 UTC) |
| État affiché des tâches situées **en aval** de la tâche échouée | `upstream_failed` |

Vue Grid pendant la tentative 1 : ![](captures/mesure5_grid_tentative1.png)

Vue Grid après l'échec définitif : ![](captures/mesure5_grid_echec_final.png)

### Question 4.1

Après un échec définitif de verifier_broker, les tâches aval sont dans l'état `upstream_failed` ce qui indique clairement qu'elles n'ont pas pu être exécutée. elle ne sont pas la source de l'erreur, juste une conséquence.

### 4.3 — Reprise

`tasks clear --task-regex "verifier_broker" --downstream` sur le run `manual__2026-11-19T14:02:50+00:00`, après `docker compose start kafka` : les 7 tâches rejouées passent en `success`, `creer_table_rapport` n'est pas relancée.

### Mesure 6 — idempotence

Fenêtre 2026-11-19 13:00 UTC, `ecrire_rapport` rejouée seule deux fois sur le run `manual__2026-11-19T14:02:50+00:00`.

| Grandeur | Valeur relevée |
| --- | --- |
| Nombre de lignes dans `ingestion_report` pour la fenêtre, après 1 exécution | `1` |
| Nombre de lignes pour la même fenêtre, après 2 rejeux | `1` |
| Valeur de `run_count` après les rejeux | `4` (1 au run planifié, 2 après la reprise 4.3, puis +1 par rejeu) |
| Nombre de fichiers dans `data/rapports/` pour cette heure | `1` (`ingestion_20261119_13.json`, réécrit à 15:12) |

### Question 4.2

Ce n'est pas un défault nécessaire à corriger, c'est ici acceptable. La clé primaire (kafka_partition, kafka_offset) garranti l'unicité des données, il n'y aura pas de doublons. Si on relance produire_fenetre et que les données existent déjà, elle ne seront pas doublé, et si elles n'existent pas elle seront correctement intégrée

## Partie 5 — Mesure

### Mesure 7 — profil de durée d'un run réussi

Run `manual__2026-11-19T14:29:53+00:00` (durées lues dans `task_instance.duration` et `dag_run` de la base `airflow`).

| Tâche | Durée relevée |
| --- | --- |
| `verifier_broker` | `0,39` s |
| `produire_fenetre` | `60,67` s |
| `controler_lag` | `0,49` s |
| `verifier_integrite` + `ecrire_rapport` | `1,14` s (0,57 + 0,57) |
| **Durée totale du DagRun** | `71,8` s (14:29:54,2 → 14:31:06,0 UTC) |

Somme des durées des 8 tâches : `63,55` s, soit un écart de `8,25` s avec la durée du DagRun.

### Question 5.1

L'écart est de 8.25s.
En regardant de plus près chaques étapes, on peut voir à peu près 1s entre chaque tache d'un DAG. creer_table_rapport finit à 14:29:56,13, verifier_broker commence à 14:29:57,11.
Une explication possible serait un délai interne si chaque tache fonctionne avec un systeme de poll qui fait un status check sur sa tache précédentes. Un autre explication possible serait un overhead entre les taches créé par airflow qui pourrait correspondre à un traitement de l´état de la tâche, ou autres vérification qui garranti un bon fonctionnement de la pipeline.

### Mesure 8 — rattrapage

`airflow dags backfill healthstream_ingestion --start-date "2026-11-19T07:00:00+01:00" --end-date "2026-11-19T09:00:00+01:00" --reset-dagruns --yes`, sur des fenêtres où `vitals_raw` ne contient aucune ligne (`ingested_at` entre 06:00 et 09:00 UTC).

| Grandeur | Valeur relevée |
| --- | --- |
| Nombre de DagRun créés par le backfill | `1` sur 3 prévus (`finished run 1 of 3`, puis `BackfillUnfinished` : le backfill s'arrête au premier run en échec, `max_active_runs=1` les lançant un par un) |
| Nombre de lignes ajoutées dans `ingestion_report` | `0` (4 lignes avant, 4 après) |
| Nombre de ces runs ayant échoué, et sur quelle tâche | `1`, `backfill__2026-11-19T07:00:00+01:00` sur `verifier_integrite` (3 tentatives, `aucune ligne dans vitals_raw sur la fenêtre`) ; `ecrire_rapport` et `fin_pipeline` en `upstream_failed` |

### Question 5.2

rows_ingested ne compte que ce qui a réellement été écrit en base entre 10 h et 11 h : 0 si la chaîne ne tournait pas, le vrai volume sinon. Les messages produits par le rattrapage à 14 h reçoivent un ingested_at de 14 h, ils tombent donc dans la fenêtre courante et pas dans celle qu'on rattrape. Un rattrapage ne peut pas créer des données passées : mais il peut retraiter que ce qui a été conservé. Il faudrait donc qu'un run portant sur une fenêtre passée saute produire_fenetre et se contente de relire les données déjà enregistrées pour cette fenêtre.

### 5.3 — Contrôle final

| Contrôle | Résultat |
| --- | --- |
| `dags list-import-errors` | `No data found` (aucune erreur d'import) |
| Dernier run | `manual__2026-11-19T14:29:53+00:00` en `success` |
| `SELECT count(*) FROM ingestion_report` | `5` |
| `data/rapports/` | 5 fichiers (`ingestion_20261119_10.json` à `ingestion_20261119_14.json`) |
| `data/alertes/` | 2 fichiers (`verifier_broker` du run manuel, `verifier_integrite` du backfill) |

## Nettoyage

| Contrôle de fin | Valeur relevée |
| --- | --- |
| Taille du dossier `logs/` après la séance | `2,2M` |
| Nombre de conteneurs encore en vie (`docker ps -q \| wc -l`) | `4`, tous hors projet : `docker compose ps -a` est vide |

Volumes conservés par `down` sans `-v` : `s1-vitals-stream_kafka-logs`, `s1-vitals-stream_pg-data`, `s1-vitals-stream_vitals-logs`.

### Question 6.1

Tout est conservé. (a) Les DAG sont des fichiers Python dans ./dags, sur le disque de l’hôte : ils ne sont pas supprimés. (b) L’historique des DagRun et des tentatives est dans la base airflow (tables dag_run, task_instance), hébergée par notre Postgres existant, dont les données sont dans le volume pg-data. Pareil pour (c) les lignes de vital_raw et (d) nos utilisateurs
Sans -v, le volume est conservé, donc tout est retrouvé au prochain démarrage.

## Contrat d'interface vers la séance 4

| Élément | Valeur |
| --- | --- |
| Nombre de lignes déjà présentes dans `vitals_raw` | `86244` |
